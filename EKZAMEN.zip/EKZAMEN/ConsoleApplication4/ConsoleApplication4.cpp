﻿#include <iostream>
#include <string>
#include <stack>

//=================== Document ===================
class Document {
    std::string name;
public:
    Document(const std::string& n) : name(n) {}
    void open() { std::cout << "[Document] Open: " << name << "\n"; }
    void save() { std::cout << "[Document] Save: " << name << "\n"; }
    void print() { std::cout << "[Document] Print: " << name << "\n"; }
    void send() { std::cout << "[Document] Send: " << name << "\n"; }
    const std::string& getName() const { return name; }
};

//=================== Command ===================
class Command {
public:
    virtual void execute() = 0;
    virtual void undo() = 0;
    virtual ~Command() {}
};

class OpenCommand : public Command {
    Document* doc;
public:
    OpenCommand(Document* d) : doc(d) {}
    void execute() override { doc->open(); }
    void undo() override { std::cout << "[Undo] Close document: " << doc->getName() << "\n"; }
};

class SaveCommand : public Command {
    Document* doc;
public:
    SaveCommand(Document* d) : doc(d) {}
    void execute() override { doc->save(); }
    void undo() override { std::cout << "[Undo] Revert save of: " << doc->getName() << "\n"; }
};

class PrintCommand : public Command {
    Document* doc;
public:
    PrintCommand(Document* d) : doc(d) {}
    void execute() override { doc->print(); }
    void undo() override { std::cout << "[Undo] Cancel print of: " << doc->getName() << "\n"; }
};

class SendCommand : public Command {
    Document* doc;
public:
    SendCommand(Document* d) : doc(d) {}
    void execute() override { doc->send(); }
    void undo() override { std::cout << "[Undo] Recall send of: " << doc->getName() << "\n"; }
};

//=================== Invoker ===================
class Invoker {
    std::stack<Command*> history;
public:
    void executeCommand(Command* cmd) {
        cmd->execute();
        history.push(cmd);
    }

    void undoLastCommand() {
        if (!history.empty()) {
            Command* cmd = history.top();
            cmd->undo();
            history.pop();
            delete cmd;
        }
    }

    ~Invoker() {
        while (!history.empty()) {
            delete history.top();
            history.pop();
        }
    }
};

//=================== Chain of Responsibility ===================
class Handler {
protected:
    Handler* next = nullptr;
public:
    void setNext(Handler* n) { next = n; }

    void handle(Document* doc) {
        process(doc);
        if (next) next->handle(doc);
    }

    virtual void process(Document* doc) = 0;
    virtual ~Handler() {}
};

class PermissionHandler : public Handler {
public:
    void process(Document* doc) override {
        std::cout << "[PermissionHandler] Checking permissions for: " << doc->getName() << "\n";
    }
};

class LoggingHandler : public Handler {
public:
    void process(Document* doc) override {
        std::cout << "[LoggingHandler] Logging action on: " << doc->getName() << "\n";
    }
};

class FormatHandler : public Handler {
public:
    void process(Document* doc) override {
        std::cout << "[FormatHandler] Converting format for: " << doc->getName() << "\n";
    }
};

//=================== Main Test ===================
int main() {
    Document doc("MyDocument.txt");

    // Setup Chain of Responsibility
    PermissionHandler permission;
    LoggingHandler logging;
    FormatHandler format;

    permission.setNext(&logging);
    logging.setNext(&format);

    std::cout << "--- Processing document through the chain ---\n";
    permission.handle(&doc);

    std::cout << "\n--- Executing commands ---\n";
    Invoker invoker;
    invoker.executeCommand(new OpenCommand(&doc));
    invoker.executeCommand(new SaveCommand(&doc));
    invoker.executeCommand(new PrintCommand(&doc));
    invoker.executeCommand(new SendCommand(&doc));

    std::cout << "\n--- Undoing last two commands ---\n";
    invoker.undoLastCommand();
    invoker.undoLastCommand();

    return 0;
}
